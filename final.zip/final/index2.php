<?php 

if (isset($_GET['action'])) {
$accion = $_GET['id'];
  echo $accion;
  $mostrar=simplexml_load_file("estudiantes.xml");
  $id= $_GET['id'];
  $index2 = 0; 
  $i = 0; 
  foreach ($mostrar as $key => $estudiante) {
    if($estudiante['id']==$id){

      $index2 = $i; 
      break;
    }
    # code...
    $i++;
  }
unset($mostrar->estudiante[$index2]);
file_put_contents('estudiantes.xml', $mostrar->asXML());
  # code...
}


 ?>




<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 <link rel="stylesheet" href="estilos.css">
    <title>Estudiantes</title>
  </head>
  <body> 
<header >
 <nav class="navbar fixed-top navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Matrícula Academica</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavDropdown">
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="index.php">Crear Tablas</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="relacionar.php">Relacionar</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="index2.html">Registrar<span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Dropdown link
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </li>
    </ul>
  </div>
</nav>
 
  </header>
 <br><br><br><br><br>
    <h1 style="text-align: center;"> Bienvenido, Seleccione una opcion </h1> 
   <div >
 





<p>

 
      

 <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#multiCollapseExample1" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">Registrar materia</a>
  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#multiCollapseExample2" aria-expanded="false" aria-controls="multiCollapseExample2">Registrar estudiantes</button>
   <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#multiCollapseExample4" aria-expanded="false" aria-controls="multiCollapseExample4">ver estudiantes</button>
  <button class="btn btn-primary" type="button" data-toggle="collapse" data-target=".multi-collapse" aria-expanded="false" aria-controls="multiCollapseExample1 multiCollapseExample2">Actualizar</button>
</p>
<div class="row">
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample1">
      <div class="card card-body">
       <form method="post" action="ingresar.php">
  <div class="form-group">
    <label for="exampleFormControlInput1">id</label>
    <input name="id" type="text" class="form-control" id="exampleFormControlInput1" placeholder="id">
  </div>
<div class="form-group">
    <label for="exampleFormControlInput1">nombre</label>
    <input name="nombre" type="text" class="form-control" id="exampleFormControlInput1" placeholder="13">
  </div>
   <div class="form-group">
    <label for="exampleFormControlTextarea1">hora</label>
    <input type="text" name="hora" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>
 <div class="form-group">
    <label for="exampleFormControlTextarea1">profesor</label>
    <input type="text" name="profesor" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>
  <div class="form-group">
    <label for="exampleFormControlTextarea1">creditos</label>
    <input type="text" name="creditos" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>
  <p><input type="submit" name="submit1" /></p>
</form>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample2">
      <div class="card card-body">
        <div>
 <form method="post" action="ingresar.php">

  <div class="form-group">
    <label for="exampleFormControlInput1">id</label>
    <input name="id" type="text" class="form-control" id="exampleFormControlInput1" placeholder="id">
  </div>


  <div class="form-group">
    <label for="exampleFormControlInput1">Nombre</label>
    <input name="nombre" type="text" class="form-control" id="exampleFormControlInput1" placeholder="ponga su nombre aqui">
  </div>
<div class="form-group">
    <label for="exampleFormControlInput1">edad</label>
    <input name="edad" type="text" class="form-control" id="exampleFormControlInput1" placeholder="13">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">sexo</label>
    <select name="sexo" class="form-control" id="exampleFormControlSelect1">
      <option>Masculino</option>
      <option>Femenino</option>
     
    </select>
  </div>
 <div class="form-group">
    <label for="exampleFormControlTextarea1">correo</label>
    <input type="text" name="correo" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>


<div class="form-group">
    <label for="exampleFormControlTextarea1">materias</label>
   <?php
  $mostrar=simplexml_load_file("materias.xml");

  foreach ($mostrar as $key => $materia) {
                    echo "<div class='form-check'>";
                   echo "<input class='form-check-input' type='checkbox' name='cb[]' value='".$materia->nombre."' id='defaultCheck1'>";
                      echo "<label class='form-check-label' for='defaultCheck1'>";
echo $materia->nombre;
                   echo " </label>";

                 }

                   echo "</div>";
                   ?>

                   
  </div>



</form>







  <div class="form-group">
    <label for="exampleFormControlTextarea1">comentarios</label>
    <input type="text" name="comentarios" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>
  <p><input type="submit" name="submit" /></p>
</form>


</div>
      </div>
    </div>
  </div>
</div>
 
  </div>
    </div>
  </div>
</div>
<div class="col">
    <div class="collapse multi-collapse" id="multiCollapseExample4">
      <div class="card card-body">




        <?php
  $mostrar=simplexml_load_file("estudiantes.xml");
   $mostrar2=simplexml_load_file("estudiantes.xml");
    echo"<table class='table'>";
    echo "  <thead>";
      echo "<tr>";
      echo "<td color='white'><strong >nombre</strong></td>";
      echo "<td><strong color='white'>edad</strong></td>";
       echo "<td><strong color='white'>materias</strong></td>";
      echo "</tr>";
      echo "</thead>";
     
  foreach ($mostrar as $key => $estudiante) {

                   echo "<tr>";
                      echo "<td >".$estudiante->nombre."</td>";
                   echo "<td >".$estudiante->edad."</td>";
                     $a=0;
                 foreach ($mostrar2 as $key => $materia) {
                   # code...
                  echo "<td >".$estudiante->materia->$a."</td>";
                  $a++;
                 }


  
               ?>
            
<td align="center"> <a href="actualizar.php?id=<?php echo $estudiante['id'];?>">Editar </a>|<a href="index2.php?action=delete&id=<?php echo $estudiante['id'];?>" onclick="return confirm('estas seguro?')">Delete</a></td>
               <?php 
          
                   echo "</tr>";
 
                 }

                   ?>
        <div>

     </div>
    
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
   
  </body>
   

 
 
</html>