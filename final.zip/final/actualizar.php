<?php
$xml = simplexml_load_file("estudiantes.xml"); 

 if (isset($_POST['actualizar'])) {

 foreach ($xml->estudiante as $estudiante) {

if($estudiante['id']==$_POST['id']) {

	$estudiante->nombre = $_POST['nombre'];
$estudiante->edad = $_POST['edad'];
$estudiante->sexo = $_POST['sexo'];
$estudiante->correo = $_POST['correo'];
foreach ($xml as $key => $materia) {
	# code...
}
foreach ($_POST['cb'] as $selected) {
	# code...
$variable =$selected;
$estudiante->materia=$selected;
}

$estudiante->comentarios = $_POST['comentarios'];



break;
}

}
file_put_contents('estudiantes.xml', $xml->asXML()); 
header('location:index.php');
 	# code...
 
 	# code...
 }












foreach ($xml->estudiante as $estudiante) {

if($estudiante['id']==$_GET['id']) {

$id = $estudiante['id'];

$nombre= $estudiante->nombre;
$edad= $estudiante->edad;
$sexo= $estudiante->sexo;
$correo= $estudiante->correo;
foreach ($xml as $key => $estudiante) {
	# code...
	$materia=$estudiante->materia;
}

echo $materia;
$comentarios= $estudiante->comentarios;
break;

}




	# code...
}








 ?>
<!DOCTYPE html>
<html>
<head>
	  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 <link rel="stylesheet" href="estilos.css">
    <title>Actualizar</title>
</head>
<body>
 <form method="post">

  <div class="form-group">
    <label for="exampleFormControlInput1">id</label>
    <input name="id" type="text" value="<?php echo $id;  ?>" class="form-control" id="exampleFormControlInput1" placeholder="id">
  </div>


  <div class="form-group">
    <label for="exampleFormControlInput1">Nombre</label>
    <input name="nombre" type="text" value="<?php echo $nombre;  ?>" class="form-control" id="exampleFormControlInput1" placeholder="ponga su nombre aqui">
  </div>
<div class="form-group">
    <label for="exampleFormControlInput1">edad</label>
    <input name="edad" type="text" value="<?php echo $edad;  ?>" class="form-control" id="exampleFormControlInput1" placeholder="13">
  </div>
  <div class="form-group">
    <label for="exampleFormControlSelect1">sexo</label>
    <select name="sexo" class="form-control" id="exampleFormControlSelect1">
      <option>Masculino</option>
      <option>Femenino</option>
     
    </select>
  </div>
 <div class="form-group">
    <label for="exampleFormControlTextarea1">correo</label>
    <input type="text" name="correo" value="<?php echo $correo;  ?>" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>


<div class="form-group">
    <label for="exampleFormControlTextarea1">materias</label>
   <?php
  $mostrar=simplexml_load_file("materias.xml");

  foreach ($mostrar as $key => $materia) {
                    echo "<div class='form-check'>";
                   echo "<input class='form-check-input' type='checkbox' name='cb[]' value='".$materia->nombre."' id='defaultCheck1'>";
                      echo "<label class='form-check-label' for='defaultCheck1'>";
echo $materia->nombre;
                   echo " </label>";

                 }

                   echo "</div>";
                   ?>

                   
  </div>


  <div class="form-group">
    <label for="exampleFormControlTextarea1">comentarios</label>
    <input type="text" name="comentarios" value="<?php echo $comentarios;  ?>" class="form-control" id="exampleFormControlTextarea1" rows="3"></input>
  </div>
  <p><input type="submit" name="actualizar" /></p>
</form>
</body>
</html>
 