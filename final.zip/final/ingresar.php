<html>
<body>
<?php 
/*$reset=$_POST['reset'];
foreach ($fichas as $ficha) {
	
fwrite($fp, '<#'.$rompecabezas->ficha['id'].'{'. PHP_EOL);
fwrite($fp, ' transform: rotate('.$rompecabezas->ficha->posicionAsociada['grados'].');'. PHP_EOL);
fwrite($fp, '}'. PHP_EOL);
fclose($fp);
}
 */

if (isset($_POST['submit'])) {
	$xml = new DOMDocument(); 
$xml->load("estudiantes.xml");
 





$nombre = $_POST["nombre"];
$edad = $_POST["edad"];
$sexo = $_POST["sexo"];
$correo = $_POST["correo"];
$comentarios = $_POST["comentarios"];




$id1= $_POST["id"];



$raiz= $xml->getElementsByTagName("estudiantes")->item(0); 
$id= $xml->createAttribute("id");
$id->value= $id1;
$estudiante= $xml->createElement("estudiante"); 
foreach ($_POST['cb'] as $selected) {
	# code...
$variable =$selected;
$variable=$xml->createElement("materia",$variable);
$estudiante->appendChild($variable); 
}

$nombre=$xml->createElement("nombre",$nombre);
$edad=$xml->createElement("edad",$edad);
$sexo=$xml->createElement("sexo",$sexo);
$correo=$xml->createElement("correo",$correo);

$comentarios=$xml->createElement("comentarios",$comentarios);




$estudiante->appendChild($id);
$estudiante->appendChild($nombre);

$estudiante->appendChild($edad);

$estudiante->appendChild($sexo);

$estudiante->appendChild($correo);

$estudiante->appendChild($comentarios); 
 $mostrar=simplexml_load_file("materias.xml");
 






$raiz->appendChild($estudiante);


$xml->save('estudiantes.xml');






}

if (isset($_POST['submit1'])) {
	$xml = new DOMDocument(); 
$xml->load("materias.xml");


$id = $_POST["id"];
$nombre = $_POST["nombre"];
$hora = $_POST["hora"];
$profesor = $_POST["profesor"];
$creditos = $_POST["creditos"];




$raiz= $xml->getElementsByTagName("materias")->item(0); 
$materia= $xml->createElement("materia"); 


$id=$xml->createElement("id",$id);
$nombre=$xml->createElement("nombre",$nombre);
$hora=$xml->createElement("hora",$hora);
$profesor=$xml->createElement("profesor",$profesor);
$creditos=$xml->createElement("creditos",$creditos);




$materia->appendChild($id);
$materia->appendChild($nombre);
$materia->appendChild($hora);
$materia->appendChild($profesor);
$materia->appendChild($creditos); 


$raiz->appendChild($materia);
$xml->save('materias.xml');




}
	# code...

/*echo $_POST["nombre"]; ?><br>
edad: <?php echo $_POST["edad"];
$fp = fopen("registro.xml","w+");
fwrite($fp, '<?xml version="1.0" encoding="UTF-8" ?> '. PHP_EOL);
fclose($fp);
?> <br>
<?php
echo "escrito";*/
























 ?>




</body>
</html>

	




    
